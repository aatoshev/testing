from recipes.profile_user.models import ProfileUser

def get_profile():
    return ProfileUser.objects.first()
