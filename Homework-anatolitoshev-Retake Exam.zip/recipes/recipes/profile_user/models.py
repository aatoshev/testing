from django.core.validators import MinLengthValidator
from django.db import models

from recipes.profile_user.validators import validate_first_name_starts_with_capital


# Create your models here.

class ProfileUser(models.Model):
    NICKNAME_MAX_LENGTH = 20
    NICKNAME_MIN_LENGTH = 2
    NICKNAME_ERROR_MESSAGE = "Nickname must be at least 2 chars long!"

    FIRST_NAME_MEX_LENGTH = 30
    LAST_NAME_MEX_LENGTH = 30


    nickname = models.CharField(
        max_length=NICKNAME_MAX_LENGTH,
        validators=[MinLengthValidator(NICKNAME_MIN_LENGTH, message=NICKNAME_ERROR_MESSAGE),],
        null=False,
        blank=False,
        unique=True,
    )

    first_name = models.CharField(
        max_length=FIRST_NAME_MEX_LENGTH,
        validators=[validate_first_name_starts_with_capital],
        null=False,
        blank=False,
    )

    last_name = models.CharField(
        max_length=LAST_NAME_MEX_LENGTH,
        validators=[validate_first_name_starts_with_capital],
        null=False,
        blank=False,
    )

    chef = models.BooleanField(
        null=False,
        blank=False,
        default=False,
    )

    bio = models.TextField(
        null=True,
        blank=True,
    )

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'
