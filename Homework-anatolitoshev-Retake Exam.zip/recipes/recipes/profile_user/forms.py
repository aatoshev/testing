from django import forms

from recipes.profile_user.models import ProfileUser


class CreateProfileUserForm(forms.ModelForm):
    class Meta:
        model = ProfileUser
        fields = ('nickname', 'first_name', 'last_name', 'chef')
        # widgets = {
        #     'password': forms.PasswordInput(),
        # }
