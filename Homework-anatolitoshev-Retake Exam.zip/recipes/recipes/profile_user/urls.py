from django.urls import path

from recipes.profile_user.views import create_profile, DetailsProfileView, EditProfileView, DeleteProfileView

urlpatterns = (
    path('create/', create_profile, name='create-profile'),
    path('details/', DetailsProfileView.as_view(), name='details-profile'),
    path('edit/', EditProfileView.as_view(), name='edit-profile'),
    path('delete/', DeleteProfileView.as_view(), name='delete-profile'),
)