from django.forms import modelform_factory
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import generic as views

from recipes.common.form_mixin import GetContextDataFormMixin
from recipes.common.utils import get_profile
from recipes.profile_user.forms import CreateProfileUserForm
from recipes.profile_user.models import ProfileUser
from recipes.recipe.models import Recipe


def create_profile(request):
    profile = get_profile()
    form = CreateProfileUserForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('catalogue')

    context = {
        'profile': profile,
        'form': form,
    }

    return render(request, 'profiles/create-profile.html', context)


class DetailsProfileView(views.DetailView):
    template_name = 'profiles/details-profile.html'
    profile = get_profile()
    # cars = Car.objects.filter(owner=profile)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["profile"] = get_profile()
        context["number"] = Recipe.objects.filter(author=get_profile()).count()
        return context

    def get_object(self, queryset=None):
        return get_profile()


class EditProfileView(GetContextDataFormMixin, views.UpdateView):
    queryset = ProfileUser.objects.all()
    template_name = 'profiles/edit-profile.html'
    form_class = modelform_factory(
        ProfileUser,
        fields=('nickname', 'first_name', 'last_name', 'chef', 'bio'),

    )

    success_url = reverse_lazy('details-profile')

    def get_object(self, queryset=None):
        return get_profile()


class DeleteProfileView(GetContextDataFormMixin, views.DeleteView):
    template_name = 'profiles/delete-profile.html'
    success_url = reverse_lazy('home-page')

    def get_object(self, queryset=None):
        return get_profile()
