from django.urls import path

from recipes.web.views import index

urlpatterns = (
    path('', index, name='home-page'),
)
