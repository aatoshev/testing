from django.shortcuts import render

from recipes.common.utils import get_profile


def index(request):
    profile = get_profile()
    context = {
        'profile': profile
    }

    return render(request, 'web/home-page.html', context)
