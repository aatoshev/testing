from django.forms import modelform_factory
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import generic as views
from django import forms

from recipes.common.form_mixin import GetContextDataFormMixin
from recipes.common.utils import get_profile
from recipes.recipe.forms import CreateRecipeForm
from recipes.recipe.models import Recipe


def create_recipe(request):
    profile = get_profile()
    form = CreateRecipeForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.instance.author = profile
            form.save()
            return redirect('catalogue')
    context = {
        'profile': profile,
        'form': form,
    }
    return render(request, 'recipes/create-recipe.html', context)


def catalogue(request):
    profile = get_profile()
    recipes = Recipe.objects.all()
    context = {
        'profile': profile,
        'recipes': recipes,
    }

    return render(request, 'web/catalogue.html', context)


class DetailRecipeView(GetContextDataFormMixin, views.DetailView):
    queryset = Recipe.objects.all()
    template_name = 'recipes/details-recipe.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["splitted"] = self.get_object().ingredients.split(', ')
        return context



class EditRecipeView(GetContextDataFormMixin, views.UpdateView):
    queryset = Recipe.objects.all()
    template_name = 'recipes/edit-recipe.html'
    success_url = reverse_lazy('catalogue')
    form_class = CreateRecipeForm


class DeleteRecipeView(GetContextDataFormMixin, views.DeleteView):
    queryset = Recipe.objects.all()
    template_name = 'recipes/delete-recipe.html'
    success_url = reverse_lazy('catalogue')
    form_class = modelform_factory(
        Recipe,
        fields=("title", "type", "ingredients", "instructions", "cooking_time", "image_url"),
        widgets={
            'title': forms.TextInput(attrs={'readonly': True}),
            'type': forms.Select(attrs={'disabled': True}),
            'ingredients': forms.TextInput(attrs={'readonly': True}),
            'instructions': forms.TextInput(attrs={'readonly': True}),
            'cooking_time': forms.NumberInput(attrs={'readonly': True}),
            'image_url': forms.URLInput(attrs={'readonly': True}),
        }
    )

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["instance"] = self.object
        return kwargs

    def post(self, *args, **kwargs):
        self.object = self.get_object()
        form = self.get_form()
        return self.form_valid(form)