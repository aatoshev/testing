from django.urls import path, include

from recipes.recipe.views import create_recipe, catalogue, DetailRecipeView, EditRecipeView, DeleteRecipeView



urlpatterns = (
    path('create/', create_recipe, name='create-recipe'),
    path('catalogue/', catalogue, name='catalogue'),
    path('<int:pk>/', include([
        path('details/', DetailRecipeView.as_view(), name='details-recipe'),
        path('edit/', EditRecipeView.as_view(), name='edit-recipe'),
        path('delete/', DeleteRecipeView.as_view(), name='delete-recipe'),
    ])),
)
