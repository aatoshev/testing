from django import forms

from recipes.recipe.models import Recipe


class CreateRecipeForm(forms.ModelForm):
    class Meta:
        model = Recipe
        fields = ("title", "type", "ingredients", "instructions", "cooking_time", "image_url")
        widgets = {
            "image_url": forms.URLInput(
                attrs={
                    "placeholder": "Optional image URL here...",
                }
            ),
            "ingredients": forms.TextInput(
                attrs={
                    "placeholder": "ingredient1, ingredient2, ....",
                },

            ),
            "instructions": forms.TextInput(
                attrs={
                    "placeholder": "Enter detailed instructions here...",
                }
            )
        }


