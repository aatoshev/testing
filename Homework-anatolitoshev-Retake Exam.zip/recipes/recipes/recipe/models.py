import profile

from django.core.validators import MinLengthValidator, MinValueValidator
from django.db import models

from recipes.profile_user.models import ProfileUser


# Create your models here.
class Recipe(models.Model):
    TITLE_MAX_LENGTH = 100
    TITLE_MIN_LENGTH = 10
    TITLE_ERROR_MESSAGE = "We already have a recipe with the same title!"

    TYPE_MAX_LENGTH = 7
    TYPE_CHOICES = (
        ("French", "French"),
        ("Chinese", "Chinese"),
        ("Italian", "Italian"),
        ("Balkan", "Balkan"),
        ("Other", "Other"),
    )

    INGREDIENTS_VERBOSE_NAME = "Ingredients must be separated by a comma and space."
    COOKING_TIME_MIN_VALUE = 1
    COOKING_TIME_VERBOSE_NAME = "Cooking Time:"
    TYPE_VERBOSE_NAME = "Cuisine Type:"
    IMAGE_VERBOSE_NAME = "Image URL:"
    INGREDIENTS_HELP_TEXT = "Ingredients must be separated by a comma and space."
    COOKING_HELP_TEXT = "Provide the cooking time in minutes."

    title = models.CharField(
        null=False,
        blank=False,
        unique=True,
        max_length=TITLE_MAX_LENGTH,
        validators=[MinLengthValidator(TITLE_MIN_LENGTH),],
        error_messages={'unique': TITLE_ERROR_MESSAGE},
    )

    type = models.CharField(
        max_length=TYPE_MAX_LENGTH,
        null=False,
        blank=False,
        choices=TYPE_CHOICES,
        verbose_name=TYPE_VERBOSE_NAME
    )

    ingredients = models.TextField(
        null=False,
        blank=False,
        help_text=INGREDIENTS_HELP_TEXT
    )

    instructions = models.TextField(
        null=False,
        blank=False,
    )

    cooking_time = models.PositiveIntegerField(
        null=False,
        blank=False,
        validators=[MinValueValidator(COOKING_TIME_MIN_VALUE),],
        verbose_name=COOKING_TIME_VERBOSE_NAME,
        help_text=COOKING_HELP_TEXT,

    )

    image_url = models.URLField(
        null=True,
        blank=True,
        verbose_name=IMAGE_VERBOSE_NAME,
    )

    author = models.ForeignKey(ProfileUser, on_delete=models.CASCADE)
